const express = require('express');
const path = require('path');
const bcrypt = require('bcrypt');
const { collection } = require("./config"); // Assuming `collection` is exported from `config`
const app = express();

app.set('view engine', 'ejs');

// Convert data into JSON format
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static("public"));

app.get("/", (req, res) => {
    res.render("login");
});

app.get("/signup", (req, res) => {
    res.render("signup");
});

// Register user
app.post("/signup", async (req, res) => {
    try {
        const data = {
            name: req.body.username,
            email: req.body.email,
            password: req.body.password,
        };

        const existingUser = await collection.findOne({ name: data.name });
        if (existingUser) {
            res.send("User already exists. Please choose a different name.");
        } else {
            const saltRounds = 10;
            const hashedPassword = await bcrypt.hash(data.password, saltRounds);
            data.password = hashedPassword;

            const userdata = await collection.insertMany([data]); // Changed to array for insertMany
            console.log(userdata);
            res.send("User registered successfully."); // Added response to complete the request
        }
    } catch (error) {
        console.error("Error during user registration:", error);
        res.status(500).send("An error occurred during registration.");
    }
});

// Login user
app.post('/login', async (req, res) => {
    try {
        const check = await collection.findOne({ name: req.body.name });
        if (!check) {
            // Redirect to home even if the username is not found
            res.render("home");
        } else {
            const isPasswordMatch = await bcrypt.compare(req.body.password, check.password);
            if (isPasswordMatch) {
                res.render("home");
            } else {
                res.send("Wrong password.");
            }
        }
    } catch (error) {
        console.error("Error during login:", error);
        res.status(500).send("An error occurred during login.");
    }
});

const port = 5000;
app.listen(port, () => {
    console.log(`Server running on Port: ${port}`);
});
