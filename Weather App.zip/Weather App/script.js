const apiKey = '09c8e1fb181bf7a72986dbf7d78b579a'; 

document.querySelector('button').addEventListener('click', () => {
    const city = document.querySelector('.search-bar').value;
    getWeather(city);
});

document.querySelector('.search-bar').addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
        const city = document.querySelector('.search-bar').value;
        getWeather(city);
    }
});

async function getWeather(city) {
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`;
    const response = await fetch(url);
    const data = await response.json();

    if (data.cod === 200) {
        displayWeather(data);
    } else {
        alert('City not found!');
    }
}

function displayWeather(data) {
    document.querySelector('.city').innerText = `Weather in ${data.name}`;
    document.querySelector('.temp h1').innerText = `${data.main.temp}°C`;
    document.querySelector('.description').innerText = data.weather[0].description;
    document.querySelector('.humidity').innerText = `Humidity: ${data.main.humidity}%`;
    document.querySelector('.wind').innerText = `Wind Speed: ${data.wind.speed} km/h`;
}
